#define __CL_ENABLE_EXCEPTIONS
#include "matrix.hpp"
#include "cl_util.hpp"
#include <omp.h>
#include <CL/cl.hpp>
#include <iostream>

using namespace std;

void print_status_msg(const matrix::mat&, const matrix::mat&, const matrix::mat&, const matrix::mat&, double);

int main(int argc, char *argv[])
{
	const int winum = 16; // Number of workitems per work group
	int N = 1024;
	double start, elapsed;

	vector<float> h_a(N * N), h_b(N * N), h_c(N * N);
	cl::Buffer d_a, d_b, d_c;

	try
	{
	  cl_util::simple_env env;
	  env.parse_args(argc, argv);

	  vector<cl::Device>& devices = env.devices;
	  cl::Device& device = env.device;

	  cout << "Using OpenCL device: " << env.get_info() << "\n";

	  cl::Context& context = env.get_context();
	  cl::CommandQueue& queue = env.get_queue();

//	  size_t d0 = 3, d1 = 5, d2 = 4;
	  size_t d0 = 2048, d1 = 1024, d2 = 3*1024;
	  matrix::mat a(d0, d1), b(d1, d2), c(d0, d2), gold(d0, d2);
	  a.rand();
	  b.rand();

	  /*
	   * CPU sequential
	   */

	  gold.zero();

	  cout << "------------------------------------------------------------" << endl;
	  cout << "-- Sequential - host CPU                                  --" << endl;
	  cout << "------------------------------------------------------------" << endl;

	  start = omp_get_wtime();

	  gold.mult(a, b);

	  elapsed  = omp_get_wtime() - start;
	  print_status_msg(a, b, gold, gold, elapsed);

	  /*
	   * Init buffers
	   */

	  d_a = cl::Buffer(context, a.begin(), a.end(), true);
	  d_b = cl::Buffer(context, b.begin(), b.end(), true);
	  d_c = cl::Buffer(context, CL_MEM_WRITE_ONLY, sizeof(matrix::num_t) * c.size());

	  /*
	   * OpenCL unroll 2 loops
	   */

	  cl::Program prog(context, cl_util::load_prog("mul0.cl"), true);
	  cl::make_kernel<int, int, int, cl::Buffer, cl::Buffer, cl::Buffer> mul0(prog, "mul0");

	  cout << "------------------------------------------------------------" << endl;
	  cout << "-- OpenCL unroll 2 loops                                  --" << endl;
	  cout << "------------------------------------------------------------" << endl;

	  c.zero();

	  start = omp_get_wtime();

	  // Automatic local group size.
	  mul0(cl::EnqueueArgs(queue, cl::NDRange(c.get_row(), c.get_col())),
				 d0, d1, d2, d_a, d_b, d_c);

	  queue.finish();

	  elapsed  = omp_get_wtime() - start;

	  cl::copy(queue, d_c, c.begin(), c.end());

	  print_status_msg(a, b, c, gold, elapsed);

	  /*
	   * OpenCL row on work item
	   */

	  prog = cl::Program(context, cl_util::load_prog("mul1.cl"), true);
	  cl::make_kernel<int, int, int, cl::Buffer, cl::Buffer, cl::Buffer> mul1(prog, "mul1");

	  cout << "------------------------------------------------------------" << endl;
	  cout << "-- OpenCL row on work item                                --" << endl;
	  cout << "------------------------------------------------------------" << endl;

	  c.zero();

	  start = omp_get_wtime();

	  mul1(cl::EnqueueArgs(queue, cl::NDRange(c.get_row())),
	   	   d0, d1, d2, d_a, d_b, d_c);

	  queue.finish();

	  elapsed  = omp_get_wtime() - start;

	  cl::copy(queue, d_c, c.begin(), c.end());

	  print_status_msg(a, b, c, gold, elapsed);

	  /*
	   * OpenCL row on work item, A in privete memory
	   */

	  prog = cl::Program(context, cl_util::load_prog("mul2.cl"), true);
	  cl::make_kernel<int, int, int, cl::Buffer, cl::Buffer, cl::Buffer> mul2(prog, "mul2");

	  cout << "------------------------------------------------------------" << endl;
	  cout << "-- OpenCL row on work item, A in privete memory           --" << endl;
	  cout << "------------------------------------------------------------" << endl;

	  c.zero();

	  start = omp_get_wtime();

	  mul2(cl::EnqueueArgs(queue, cl::NDRange(c.get_row()), cl::NDRange(c.get_row() / winum)),
		   d0, d1, d2, d_a, d_b, d_c);

	  queue.finish();

	  elapsed  = omp_get_wtime() - start;

	  cl::copy(queue, d_c, c.begin(), c.end());

	  print_status_msg(a, b, c, gold, elapsed);

	  /*
	   * OpenCL row on work item, A row privete, B col local
	   */

	  prog = cl::Program(context, cl_util::load_prog("mul3.cl"), true);
	  cl::make_kernel<int, int, int, cl::Buffer, cl::Buffer, cl::Buffer, cl::LocalSpaceArg> mul3(prog, "mul3");

	  cout << "------------------------------------------------------------" << endl;
	  cout << "-- OpenCL row on work item, A row privete, B col local    --" << endl;
	  cout << "------------------------------------------------------------" << endl;

	  c.zero();

	  start = omp_get_wtime();

	  cl::LocalSpaceArg localmem = cl::Local(sizeof(float) * a.get_col());

	  mul3(cl::EnqueueArgs(queue, cl::NDRange(c.get_row()), cl::NDRange (c.get_row() / winum)),
		   d0, d1, d2, d_a, d_b, d_c, localmem);

	  queue.finish();

	  elapsed  = omp_get_wtime() - start;

	  cl::copy(queue, d_c, c.begin(), c.end());

	  print_status_msg(a, b, c, gold, elapsed);

	  return 0;

	  /*
	   * Blocked algorithm
	   */

	  prog = cl::Program(context, cl_util::load_prog("mul4.cl"), true);
	  cl::make_kernel<int, int, int, cl::Buffer, cl::Buffer, cl::Buffer, cl::LocalSpaceArg, cl::LocalSpaceArg> mul4(prog, "mul4");

	  cout << "------------------------------------------------------------" << endl;
	  cout << "-- Blocked algorithm                                      --" << endl;
	  cout << "------------------------------------------------------------" << endl;
	  c.zero();

	  start = omp_get_wtime();

	  // Work-group computes a block of C.  This size is also set
	  // in a #define inside the kernel function.  Note this blocksize
	  // must evenly divide the matrix order
	  int blocksize = 16;

	  cl::LocalSpaceArg A_block = cl::Local(sizeof(float) * blocksize*blocksize);
	  cl::LocalSpaceArg B_block = cl::Local(sizeof(float) * blocksize*blocksize);

	  mul4(
		  cl::EnqueueArgs(
			  queue,
			  cl::NDRange(N,N),
			  cl::NDRange(blocksize,blocksize)),
		  d0,
		  d1,
		  d2,
		  d_a,
		  d_b,
		  d_c,
		  A_block,
		  B_block);

	  queue.finish();

	  elapsed = omp_get_wtime() - start;

	  cl::copy(queue, d_c, h_c.begin(), h_c.end());

	  print_status_msg(a, b, c, gold, elapsed);
    }
	catch (cl::Error err)
    {
		cout << "Exception" << endl;
		cerr << "ERROR: " << err.what() << endl;
		if (err.err() == CL_BUILD_PROGRAM_FAILURE)
		{
			cout << cl_util::get_build_log("mul3.cl");
		}
    }

	return 0;
}

void print_status_msg(
	const matrix::mat& a,
	const matrix::mat& b,
	const matrix::mat& c0,
	const matrix::mat& c1,
	double elapsed)
{
	if (c0 == c1)
	{
		cout << "Matrices are equal." << endl;
		cout << "Elapsed time : " << elapsed << endl;
		cout << "MFLOPS       : " << ((double)get_mul_ops(a, b, elapsed)) / (1000000.0f * elapsed);
		cout << endl;
	}
	else
	{
		cout << "ERROR: Matrices are not equal!" << endl;
		cout << "-----------------------" << endl;
		cout << c0 << endl;
		cout << "-----------------------" << endl;
		cout << c1 << endl;
	}
}
